package controleur;

import vue.Arene;
import vue.ChoixArme;
import vue.ChoixJoueur;
import vue.EntreeJeu; //package.Maclasse
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;

import modele.Jeu;
import modele.JeuClient;
import modele.JeuServeur;
import modele.Label;
import outils.connexion.ClientSocket;
import outils.connexion.Connection;
import outils.connexion.ServeurSocket;

public class Controle 
implements Global
{
	private EntreeJeu frmEntreeJeu ;
	private Jeu leJeu;
	private Arene frmArene;
	private ChoixJoueur frmChoixJoueur;
	private ChoixArme frmChoixArme;
	private Connection connection;

	
	public static void main(String[] args) {
		new Controle(); //objet controle
	}
	
	//Constructeur 
	public Controle()
	{
		this.frmEntreeJeu = new EntreeJeu(this); // On affecte a la propriete frmEntreeJeu une instance de la classe correspondance 
		this.frmEntreeJeu.setVisible(true); //on rend visible la fenetre
	}
	
	//Methode evenementVue
	
	public void evenementVue(JFrame uneFrame , Object info)
	{
		//si uneFrame est un objet de type EntreeJeu
		if (uneFrame instanceof EntreeJeu)
		{
			evenementEntreeJeu(info);//alors on appelle la methode evenementVue
		}else 
			if (uneFrame instanceof ChoixJoueur)
		{
			evenementChoixJoueur(info);
		}else if (uneFrame instanceof Arene)
		{
			evenementArene(info);
		}else if (uneFrame instanceof ChoixArme)
		{
			evenementChoixArme(info);
		}
		
	
	}
	
	private void evenementArene(Object info) {
		// TODO Auto-generated method stub
		((JeuClient)leJeu).envoi(info); //on attend l'objet a transferer ici puis on l'envoie lorsqu'on l'as receptionne
	}

	//Methode setconnection
	
	public void setConnection(Connection connection)
	{
		//on valorise setConnection
		this.connection = connection;
		
		if (leJeu instanceof JeuServeur) //on verifie si lejeu est une instance de JeuServeur
		{
			leJeu.setConnetion(connection);//on etablie une connection sur leJeu
		}
		
	}
	
	//Methode receptioninfo
	
	public void receptioninfo(Connection connection , Object info)
	{
		leJeu.reception(connection, info);
	}

	private void evenementEntreeJeu(Object info) {
		// TODO Auto-generated method stub
	//	System.out.println((String)info); //on transtype afin d'afficher le parametre info dans la console car de base c'est un objet
		if ((String) info == "serveur")
		{
			new ServeurSocket(this , PORT);//this correspond a l'instance actuelle de Controle //on va utiliser egalement comme deuxieme parametre le port 6666 qui est libre
			leJeu = new JeuServeur(this); //un jeu de type serveur a ete cree
			frmEntreeJeu.dispose();//on ferme la fenetre entree de jeu
			frmArene = new Arene("serveur", this);//on cree une instance de Arene 
			((JeuServeur)leJeu).constructionMurs();//on appelle a methode constructionMurs sur l'objet leJeu , apres l'avoir transtype en JeuServeur
			frmArene.setVisible(true);//on rend la nouvelle fenetre visible
		}
		else 
		{
			(new ClientSocket((String) info , PORT , this)).isConnexionOk();
			leJeu = new JeuClient(this);
			leJeu.setConnetion(connection); // a partir d'ici le client pourra envoyer les infos au serveur
			frmEntreeJeu.dispose(); //on ferme la fenetre entreejeu
			frmArene = new Arene("client" , this);
			frmChoixJoueur = new ChoixJoueur(this); //on revoie a la frame l'instance actuelle de controle
			frmChoixJoueur.setVisible(true); //on rend visible la fenetre ChoixJoueur
		}
		
		
		
	}
	
	private void evenementChoixJoueur(Object info)
	{
		
		frmChoixJoueur.dispose();//je ferme la fenetre choixjoueur
		frmChoixArme = new ChoixArme(this, ((String)info));
		frmChoixArme.setVisible(true);//j'ouvre la fenetre Arene 
	}
	
	private void evenementChoixArme(Object info) {
		// TODO Auto-generated method stub
		((JeuClient)leJeu).envoi(info); ///j'envoie l'info vers le serveur 
		frmChoixArme.dispose();//je ferme la fenetre choixArme
		frmArene.setVisible(true);//j'ouvre la fenetre Arene 
	}
	
	
	public void evenementModele(Object unJeu , String ordre , Object info)//la methode evenementModele ici gere le fonctionnement suivant  : quel type de jeu si c'est un jeu de type client ou de type serveur , il envoie quoi donc l'ordre a traiter  et ce qu'il envoie donc l'objet a traiter
	{
		if (unJeu instanceof JeuServeur ) //on verifie si unJeu est une instance de la classe JeuServeur
		{
			evenementJeuServeur(ordre , info);
		}
		
		if (unJeu instanceof JeuClient)
		{
			evenementJeuClient(ordre , info);
		}
	}
	
	public void evenementJeuServeur(String ordre , Object info)
	{
			if (ordre.equals("ajout mur"))//on verifie ici si ordre contient la chaine "ajout murs" avec la fonction .equals
				//On s'occupe egalement de g�rer un ordre qui demande d'ajouter un nouveau mur dans l'ar�ne
			{
				frmArene.ajoutMur((JLabel)info);
			}	else if (ordre.equals("envoi panel murs"))
			{
			((JeuServeur)leJeu).envoi((Connection)info , frmArene.getJpnMurs()); // on transtype info en Connection car il possede l'objet connection pour contacter le client
			//on gere un ordre qui viendra du serveur et qui lui demandera d'envoyer le panel des murs au client
			}else if (ordre.equals("ajout joueur"))	
			{
				frmArene.ajoutJoueur((JLabel)info);
			}else if (ordre.equals("ajout phrase"))
			{
				frmArene.ajoutChat((String)info);
				((JeuServeur) this.leJeu).envoi(frmArene.getTxtChat());
			}
	}
	
	//Methode evenementJeuClient
	public void evenementJeuClient (String ordre , Object info)
	{
		if (ordre.equals("ajout panels murs" ))
		{
			frmArene.ajoutPanelMurs((JPanel)info);
		}else if (ordre.equals("ajout joueur"))
		{
			frmArene.ajoutModifJoueur(((Label)info).getNumLabel() ,((Label)info).getjLabel());
		}else if (ordre.equals("remplace chat")){
			
			frmArene.remplaceChat((String)info);
			
		}else if (ordre.equals("son"))
		{
			frmArene.joueSon((Integer)info);
		}
		
	}
	
	//Methode deconnection
	public void deconnection (Connection connection)
	{
		leJeu.deconnection(connection);
	}

}
