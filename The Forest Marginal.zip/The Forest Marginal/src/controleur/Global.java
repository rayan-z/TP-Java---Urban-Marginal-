package controleur;

public interface Global {
	
	public static final int PORT = 6666; //propriete port 
	
	
	//on cree les constantes suivante pour ne pas a avoir a les repeter a chaque fois par exemple si je veux appeler l'image de fond j'appelle FONDCHOIx
public static final String	SEPARATOR = "//";
public static final String	CHEMIN = "media" + SEPARATOR;
public static final String	CHEMINFONDS = CHEMIN + "fonds" + SEPARATOR;
public static final String	FONDCHOIX = CHEMINFONDS + "fondchoix.jpg";
public static final String FONDCHOIX2 = CHEMINFONDS + "fondchoix2.jpg";
			
//CONST pour le perso 

public static final int GAUCHE = 0; //pour la direction 
public static final int DROITE = 1;
public static final int HAUT = 2;
public static final int BAS = 3;
public static final int TIRE = 4;//pour le tire d'une boule
public static final int ACTION =2; ////Le serveur traite une action (deplacement ,tir)
public static final int NBETATSMARCHE = 4; //nombre d'etape de l'image du perso
public static final int NBETATSBLESSE = 2;
public static final int NBETATSMORT =2;
public static final int LEPAS = 10;
public static final String CHEMINPERSOS = CHEMIN + "personnages" + SEPARATOR;
public static final String PERSO = CHEMINPERSOS + "perso";
public static final String EXTIMAGE = ".png";
public static final String MARCHE = "marche"; //les diff etats
public static final String BLESSE = "touche";
public static final String MORT = "mort";
public static final int NBPERSOS = 4; //nombre de personnage
public static final int H_PERSO = 44; //taille de l'image du perso
public static final int L_PERSO = 39;

//CONST PSEUDO

public static final String SEPARE = "~";
public static final int PSEUDO = 0;


//CONST TAILLE JEU

public static final int H_ARENE = 600;
public static final int L_ARENE = 800;
public static final int H_CHAT = 200;
public static final int H_SAISIE = 25;
public static final int MARGE = 5; // elle va servir pour les �carts entre diff�rents objets

//CONST IMAGE FOND 

public static final String FONDARENE = CHEMINFONDS+"fondarene.jpg";



//CONST MUR

public static final int NBMURS = 20;
public static final String CHEMINMURS = CHEMIN + "murs" + SEPARATOR;
public static final String MUR = CHEMINMURS + "mur.jpg"; // image du mur
public static final int H_MUR = 35; // hauteur de l'image
public static final int L_MUR = 34; // largeur de l'image

///Hauteur du message

public static final int  H_MESSAGE = 8;

//CONST CHAT

public static final int CHAT = 1;


//CONST BOULE

public static final int L_BOULE = 17;
public static final int H_BOULE = 17;

public static final String CHEMINBOULES = CHEMIN + "boules" + SEPARATOR;

public static final String BOULE2 = CHEMINBOULES + "boule";


public static final int NBARMES = 4;


//CONST SON

public static final String CHEMINSONS = CHEMIN + "sons/";
public static final String SONPRECEDENT = CHEMINSONS + "precedent.wav"; // sur le clic du bouton pr�c�dent
public static final String SONSUIVANT = CHEMINSONS + "suivant.wav"; // sur le clic du bouton suivant
public static final String SONGO = CHEMINSONS + "go.wav"; // sur le clic du bouton go
public static final String SONWELCOME = CHEMINSONS + "welcome.wav"; // � l'entr�e de la frame ChoixJoueur
public static final String SONAMBIANCE = CHEMINSONS + "ambiance.wav"; // son d'ambiance dans tout le jeu
public static final int FIGHT = 0;
public static final int HURT = 1;
public static final int DEATH = 2;
public static final String[] SON = {"fight.wav", "hurt.wav", "death.wav"} ;

}



