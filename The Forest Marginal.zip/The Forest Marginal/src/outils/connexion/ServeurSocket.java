package outils.connexion;

import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;

import controleur.Controle;


//creation de la classe ServeurSocket
public class ServeurSocket extends Thread {
	
	private Object leRecepteur;
	
	//declaration de seversocket

	private ServerSocket serverSocket;
	
	//constructeur
	public ServeurSocket (Object leRecepteur , int port)
	{
		//on valorise 
		
		this.leRecepteur = leRecepteur;
		
		//creation du socket ecoute client
		try {
			this.serverSocket = new ServerSocket(port);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			System.out.println("Erreur grave du socket server");
			System.exit(0);
		} 
		//on appel la methode start
		this.start();
	}
	public void run ()
	{
		Socket socket ;
		//on boucle car nous ne connaissant pas combien de clients il y aura 
		while (true)
		{
			try {
				System.out.println("le serveur attend");
				//serveursocket se met a l'ecoute du client pour accepter leur requete
				socket = serverSocket.accept();
				System.out.println("le client est connecte");
				new Connection (socket , leRecepteur);
			} catch (IOException e) {
				// TODO Auto-generated catch block
				System.out.println("Erreur sur l'objet serveur socket");
				System.exit(0);
			}
		}
	}

}
