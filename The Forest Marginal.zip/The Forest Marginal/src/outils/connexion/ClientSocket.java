package outils.connexion;

import java.io.IOException;
import java.net.Socket;
import java.net.UnknownHostException;

import javax.swing.JOptionPane;



public class ClientSocket {
	
	//boolean
	private boolean connexionOk;

	//constructeur 
	public ClientSocket (String ip , int port , Object leRecepteur)
	{
		connexionOk = false;
		//on affecte a cet objet une instance de la classe socket en envoyant en parametre l'IP et le port
		try {
			Socket socket = new Socket (ip , port);
			System.out.println("Connexion serveur reussi");
			connexionOk = true;
			new Connection (socket , leRecepteur );
		} catch (UnknownHostException e) {
			// TODO Auto-generated catch block
			//on affiche un message box pour que l'utilisateur connaisse son erreur 
			JOptionPane.showMessageDialog(null, "Serveur non  disponible.");
		} catch (IOException e) {
			// TODO Auto-generated catch block
			JOptionPane.showMessageDialog(null, "Erreur d'Entree/Sortie");
		}
	}

	/**
	 * @return the connexionOk
	 */
	public boolean isConnexionOk() {
		return connexionOk;
	}
	
	
	
}
