package outils.connexion;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;

import javax.swing.JOptionPane;

//on cree la classe connection qui herite de la classe Thread
public class Connection extends Thread {
	//on cree la methode connection avec unObjet de type object en parametre qui correspond a l'objet a envoyer
	public synchronized void envoi (Object unObject)
	{
		try {
			this.out.reset();
			out.writeObject(unObject);//la methode s'occupe d'envoyer un objet vers l'ordi distant
		 out.flush();//on vide le canal de sortie
		} catch (IOException e) {
			// TODO Auto-generated catch block
			System.out.println("Erreur sur l'objet out");
		} 
	}
	
	private Object leRecepteur;
	//on declare en privee les deux cannaux d'entree/sortie pour communiquer avec l'ordi distant
	private ObjectInputStream in; //canal pour recevoir les messages
	private ObjectOutputStream out; //canal pour envoyer des messages
	
	public Connection (Socket socket , Object leRecepteur)
	{
	
		//on valorise
		this.leRecepteur = leRecepteur;
		
		//creation du canal de sortie
		try {
			this.out = new ObjectOutputStream(socket.getOutputStream());
		} catch (IOException e) {
			// TODO Auto-generated catch block
			System.out.println("Erreur de canal out");
		} 
		
		//creation du canal d'entree
		try {
			this.in = new ObjectInputStream(socket.getInputStream());
		} catch (IOException e) {
			// TODO Auto-generated catch block
			System.out.println("Erreur de canal in");
		}
		//on appelle la methode start 
	this.start();
	
	((controleur.Controle)this.leRecepteur).setConnection(this);
	}
	
	//creation de la methode run
	
	public void run ()
	{
		boolean inOk = true ; //utilisation d'un boolean pour savoir l'etat de connection du client c'est pourquoi on utilise pas une boucle infine 
		Object reception ; //declaration de la variable reception de type object
		
		while(inOk) //tant que inOk est vrai
		{
		try {
			reception = in.readObject(); //cette methode va attendre la reception d'un message de la part de l'ordinateur distant
			((controleur.Controle)this.leRecepteur).receptioninfo(this, reception);
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			System.out.println("Erreur de classe sur la reception");
			System.exit(0);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			JOptionPane.showMessageDialog(null , "l'ordinateur distant est deconnecte");
			inOk = false;
			((controleur.Controle)this.leRecepteur).deconnection(this);
			try {
				in.close();
			} catch (IOException e1) {
				// TODO Auto-generated catch block
				System.out.println("Erreur de canal d'entree");
			}
		}	
		}
	}
	
}
