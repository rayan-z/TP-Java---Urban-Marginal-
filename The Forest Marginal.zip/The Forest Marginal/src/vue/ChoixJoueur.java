package vue;

import java.awt.BorderLayout;
import java.awt.EventQueue;
import java.awt.Cursor;

import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import controleur.Controle;
import controleur.Global;
import outils.son.Son;

import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import javax.swing.JTextField;
import javax.swing.SwingConstants;


public class ChoixJoueur extends JFrame 
implements Global
{

	private JPanel contentPane;
	private JTextField txtPseudo;
	private int numPerso;
	private JLabel lblPersonnage;
	private Controle controle ;
	private Son precedent;
	private Son suivant;
	private Son go;
	private Son welcome;

	/**
	 * Launch the application.
	 */
//	public static void main(String[] args) {
//		EventQueue.invokeLater(new Runnable() {
//			public void run() {
//				try {
//					ChoixJoueur frame = new ChoixJoueur();
//					frame.setVisible(true);
//				} catch (Exception e) {
//					e.printStackTrace();
//				}
//			}
//		});
//	}
	//On cree la methode souris_normale
	private void souris_normale()
	{
		contentPane.setCursor(new Cursor(Cursor.DEFAULT_CURSOR));
		
	}
	
	//On cree la methode souris_doigt
	private void souris_doigt()
	{
		contentPane.setCursor(new Cursor(Cursor.HAND_CURSOR));
		
	}
	
	//on gere les clics des labels 
	
	private void lblPrecedent_clic()
	{
		
		this.precedent.play();
		numPerso = (((numPerso % NBPERSOS) + 2)% NBPERSOS)+ 1 ; //au debut on est sur le 1er perso puis lors du 1er clic on passe au 3eme perso du coup numperso prend 3 ensuite le calcul reviendra donc a faire 3 % 3 qui font 0 + 1 = 1 % 3 = 1 + 1 = 2 donc deuxieme perso 
		affichePerso(); //On rappelle la fonction affiche Perso ;
		
	}
	
	private void lblSuivant_clic()
	{
		this.suivant.play();
		numPerso = ((numPerso % NBPERSOS) + 1); // de meme qu' en haut a chaque clic numPerso prend la valeur du calcul 
		affichePerso();
		
	}
	
	private void lblGo_clic()
	{
		this.go.play();
	if (txtPseudo.getText().equals(""))
	{
		JOptionPane.showMessageDialog(null , "Le pseudo est obligatoire");
		txtPseudo.requestFocus();
		//On verifie si la zone de texte est vide 
	}else {
		controle.evenementVue(this, PSEUDO + SEPARE + txtPseudo.getText() + SEPARE + numPerso);//ici il faut envoyer la frame qui fait appel au controleur
		//JOptionPane.showMessageDialog(null , "nickel");
	}
	}
	
	private void affichePerso()
	{
		lblPersonnage.setIcon(new ImageIcon(PERSO + numPerso + MARCHE + "1d"  + DROITE + EXTIMAGE));
	}

	/**
	 * Create the frame.
	 * @param controle 
	 */
	
	//constructeur 
	
	public ChoixJoueur(Controle controle) {
		setTitle("Choice");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 416, 313);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		//LABEL Precedent
		
		JLabel lblPrecedent = new JLabel("");
		lblPrecedent.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				lblPrecedent_clic();
				
			}
			@Override
			public void mouseEntered(MouseEvent e) {
				souris_doigt();
			}
			@Override
			public void mouseExited(MouseEvent e) {
				souris_normale();
			}
		});
		
		//LABEL SUIVANT
		
		
		JLabel lblSuivant = new JLabel("");
		lblSuivant.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				lblSuivant_clic();
				
			}
			@Override
			public void mouseEntered(MouseEvent e) {
				souris_doigt();
			}
			@Override
			public void mouseExited(MouseEvent e) {
				souris_normale();
			}
		});
		
		//LABEL GO
		
		JLabel lblGo = new JLabel("");
		lblGo.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				lblGo_clic();
				
			}
			@Override
			public void mouseEntered(MouseEvent e) {
				
				souris_doigt();
			}
			@Override
			public void mouseExited(MouseEvent e) {
				souris_normale();
			}
		});
		
		//LABEL DE Perso
		
	    lblPersonnage = new JLabel("");
		lblPersonnage.setHorizontalAlignment(SwingConstants.CENTER);
		lblPersonnage.setBounds(144, 117, 119, 120);
		contentPane.add(lblPersonnage);
		
		txtPseudo = new JTextField();
		txtPseudo.setBounds(144, 247, 119, 19);
		contentPane.add(txtPseudo);
		txtPseudo.setColumns(10);
		lblGo.setBounds(309, 199, 66, 56);
		contentPane.add(lblGo);
		lblSuivant.setBounds(302, 147, 25, 42);
		contentPane.add(lblSuivant);
		lblPrecedent.setBounds(66, 147, 32, 42);
		contentPane.add(lblPrecedent);
		
		//LABEL DE FOND
		
		JLabel lblFond = new JLabel("New label");
		lblFond.setBounds(0, 0, 400, 275);
		
		 lblFond.setIcon(new ImageIcon(FONDCHOIX));
		contentPane.add(lblFond);
		
		
		txtPseudo.requestFocus(); //le curseur va etre positionee de base dans la zone de texte
	
	numPerso = 1; //on initialise 1 a numPerso 
	
	affichePerso();
	
	//valorisation 
	this.controle = controle;
	
	this.precedent =  new Son (SONPRECEDENT);
	this.suivant =   new Son (SONSUIVANT);
	this.welcome =  new Son (SONWELCOME);
	this.welcome.play();
	this.go =  new Son (SONGO);
	
	}
	
}
