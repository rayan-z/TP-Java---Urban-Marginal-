package vue;

import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;

import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import controleur.Controle;
import controleur.Global;
import outils.son.Son;

import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.JTextArea;
import javax.swing.JScrollPane;


public class Arene extends JFrame 
implements Global
{

	private JPanel contentPane;
	private JTextField txtSaisie;
	private JTextArea txtChat;
	private JPanel jpnMurs;
	private JPanel jpnJeu;
	private boolean client; //on va pouvoir savoir si on est dans l'arene du client 
	private Controle controle ; //on donne a Arene une instance de controle 
	private Son[] lessons = new Son[SON.length] ;
	
	/**
	 * Launch the application.
	 */
//	public static void main(String[] args) {
//		EventQueue.invokeLater(new Runnable() {
//			public void run() {
//				try {
//					Arene frame = new Arene();
//					frame.setVisible(true);
//				} catch (Exception e) {
//					e.printStackTrace();
//				}
//			}
//		});
//	}

	/**
	 * Create the frame.
	 * @return 
	 */
	//constructeur
	public  Arene(String typeJeu , Controle controle) {
		//on valorise la propriete client afin de voir si il est true ou pas
		
		client = (typeJeu.equals("client")) ; //si typejeu equals client alors on valorise client on le mettant a true sinon on le met a false
		
		this.controle = controle ; //on valorise controle
		setTitle("Arena");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, L_ARENE+3*MARGE, H_ARENE + H_CHAT);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		if (client) {   //C'est sur ce Jpanel que les evenements des touches vont etre gere on entoure d'un if car c'est lignes doivent etre gere que cote client donc uniquement lorsque client est a true
			contentPane.addKeyListener(new KeyAdapter() {
				@Override
				public void keyPressed(KeyEvent arg0) {
					contentPane_keyPressed(arg0);
				}
			});
		}
		
	    jpnJeu = new JPanel();
		jpnJeu.setOpaque(false);//on le fait pour rendre le jpanel transparent
		jpnJeu.setBounds(0, 0, L_ARENE, H_ARENE);
		contentPane.add(jpnJeu);
		jpnJeu.setLayout(null);
		
	    jpnMurs = new JPanel();
		jpnMurs.setOpaque(false);
		jpnMurs.setBounds(0, 0, L_ARENE, H_ARENE);
		contentPane.add(jpnMurs);
		jpnMurs.setLayout(null);
		
		JLabel lblFond = new JLabel("");
		lblFond.setIcon(new ImageIcon(FONDARENE));
		lblFond.setBounds(0, 0, L_ARENE, H_ARENE);
		contentPane.add(lblFond);
		
		if (client) { //si le client est a true alors on passe a la creation on procede a la creation et a l'ajout de la zone de saisie
			txtSaisie = new JTextField();
			txtSaisie.setBounds(0, H_ARENE, L_ARENE, H_SAISIE);
			contentPane.add(txtSaisie);
			txtSaisie.setColumns(10);

			txtSaisie.addKeyListener(new KeyAdapter() {
//on gere l'evenement clavier
				@Override
				public void keyPressed(KeyEvent arg0) {
					txtSaisie_keyPressed(arg0);//on recup argo pour savoir quel touche a ete utilise 
				}
			});
		}
		
		JScrollPane jspChat = new JScrollPane();
		jspChat.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);
		jspChat.setBounds( 0, H_ARENE + H_SAISIE, L_ARENE, H_CHAT - H_SAISIE - 7*MARGE);
		contentPane.add(jspChat);
		
		 txtChat = new JTextArea();
		jspChat.setViewportView(txtChat);
		
		if(client){
			(new Son(SONAMBIANCE)).playContinue();
			for(int k=0;k<SON.length;k++){
				lessons[k] = new Son(CHEMINSONS+SON[k]);
			}
}
	}
	
	public void joueSon(int numSon) {
		lessons[numSon].play();
	}
	
	public void ajoutMur (JLabel unMur) //on a ici une m�thode dans la frame Arene qui permet d'ajouter un mur
	{
		jpnMurs.add(unMur);
		jpnMurs.repaint(); //actualise l'affichage (composant), de sorte que chaque fois que vous effectuez un changement sur le composant, vous devez l'appeler.
		
	}
	
	public void ajoutPanelMurs (JPanel objet)//methode qui  r�ceptionne un JPanel et transfere tout son contenu dans le JPanel des murs
	{
		jpnMurs.add(objet);
		jpnMurs.repaint();
		contentPane.requestFocus();
	}
	
	public void ajoutJoueur (JLabel unJeu)
	{
		jpnJeu.add(unJeu);
		jpnJeu.repaint();
		contentPane.requestFocus();
	}
	
	public void ajoutModifJoueur (int num , JLabel unLabel)
	{
		try {
			jpnJeu.remove(num);
		} catch (ArrayIndexOutOfBoundsException e) {
			// TODO Auto-generated catch block
			//e.printStackTrace();
		}
		
		jpnJeu.add(unLabel , num);
		jpnJeu.repaint();
		
		System.out.println(unLabel);
		
	}

	/**
	 * @return the jpnMurs
	 */
	public JPanel getJpnMurs() {
		return jpnMurs;
	}
	
	
	private void txtSaisie_keyPressed(KeyEvent arg0) {
		// TODO Auto-generated method stub
		//Nous allons faire en sorte d'envoyer l'info que si la touche est presse 
		if (arg0.getKeyCode() == KeyEvent.VK_ENTER) {//getkeycode retourne le code de la touche 
			if (txtSaisie.getText() != "") {//on verifie si la zone de saisie n'est pas vide
				controle.evenementVue(this, CHAT + SEPARE + txtSaisie.getText());//on envoie le message au serveur
				txtSaisie.setText("");//on vide le contenu de txt saisie
				contentPane.requestFocus();
				
			}
		}
	}
	
	private void contentPane_keyPressed(KeyEvent arg0) {

		int valeur = -1; //cette variable recoit la valeur de la touche utilise , bien sur faut que elle soit valide//si elle reste a -1 on ne fera rien

		switch (arg0.getKeyCode()) {
//on gere le deplacement
		case KeyEvent.VK_SPACE:
			valeur = TIRE;
			break;

		case KeyEvent.VK_LEFT:
			valeur = GAUCHE;
			break;

		case KeyEvent.VK_RIGHT:
			valeur = DROITE;
			break;

		case KeyEvent.VK_DOWN:
			valeur = BAS;
			break;

		case KeyEvent.VK_UP:
			valeur = HAUT;
			break;
		}
		if (valeur != -1) {
			controle.evenementVue(this, ACTION + SEPARE + valeur);//si il est diff de -1 on envoie l'evenement au serveur
		}
	}
	
	public void ajoutChat(String unePhrase) { //cette methode permet de mettre a jour la zone d'affichage 
		txtChat.setText(unePhrase + "\r\n" + txtChat.getText());//on modifie le contenu avec settext puis on gere un retour a la ligne et enfin on envoie l'ancien contenu du chats
	}
	
	public void remplaceChat(String remplace) {
		txtChat.setText(remplace);
	}
	
	
	public String getTxtChat() {
		return txtChat.getText() ;
	}
	
}
