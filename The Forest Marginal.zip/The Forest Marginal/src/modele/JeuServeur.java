package modele;

import java.util.ArrayList;
import java.util.Hashtable;

import controleur.Controle;
import controleur.Global;
import outils.connexion.Connection;

public class JeuServeur extends Jeu 

implements Global

{

	private ArrayList<Mur> lesMurs =  new ArrayList<Mur>();
	private Hashtable<Connection, Joueur> lesJoueurs = new Hashtable<Connection, Joueur> (); //le Hastable va permettre de gerer un dictionnaire/avec une cle/et sera de type connection 
					//la cle represente la connection dans le hastable
	private ArrayList<Joueur> lesJoueursDansLordre = new ArrayList<Joueur>();
	
	//constructeur
	public JeuServeur (Controle controle)
	{
		super.controle = controle;
		
		Label.setNbLabel(0);//on ajoute l'initialisation a 0 de la propriete statique nbLabel en passant par le setter statique 
		
	}
	
	//le override permet de reperer les methodes abstraites 
	@Override
	public void setConnetion(Connection connection) {
		// TODO Auto-generated method stub
		lesJoueurs.put(connection, new Joueur(this)); //on ajoute un nouveau joueur
		
	}

	@Override
	public void reception(Connection connection, Object info) {
		// TODO Auto-generated method stub
		//System.out.println(info);
		String[] infos = ((String)info).split(SEPARE);//on decompose l'info avec la fonction split
		
		switch(Integer.parseInt(infos[0]))//ici le switch n'accepte que des entiers donc pour le convertir on utilise un parseint sur la classe integer car on ne peut pas transtyper directement un string en int
		{
		case PSEUDO: 
			controle.evenementModele(this, "envoi panel murs", ((Object)connection));//1er parametre on met le type de jeu que l'on utlilise ici un jeu de type serveur , 2nd parametre ce qu'il envoie et le 3eme parametre l'objet a traiter
			for(Joueur joueurordre : lesJoueursDansLordre)
			{
				super.envoi(connection, joueurordre.getlabel() );
				super.envoi(connection, joueurordre.getMessage());
				super.envoi(connection, joueurordre.getBoule().getlabel());//on envoie les boules des anciens au nouveau joueur 
			}
			
			lesJoueurs.get(connection).initPerso(infos[1],Integer.parseInt(infos[2]), lesJoueurs, lesMurs , Integer.parseInt(infos[3]));
			this.lesJoueursDansLordre.add(this.lesJoueurs.get(connection)) ;
			String laPhrase = "***  " + lesJoueurs.get(connection).getPseudo() + "  vient de se connecter ***";
			controle.evenementModele(this, "ajout phrase", laPhrase);
			break;
			
			//lorsqu'un message commencera par PSEUDO c'est qu'un nouveau client viens d'envoyer le choix de son pseudo et celui du num du perso
			
		case CHAT: 
			laPhrase = lesJoueurs.get(connection).getPseudo() + ">" + infos[1];
			controle.evenementModele(this, "ajout phrase", laPhrase);
			break;
			
		case ACTION:
			//on utilise les LesJoueurs.get(connection) pour faire appel au joueur concerne , puis on envoie en premier parametre l'action qui se trouve dans infos[1]
			if (!lesJoueurs.get(connection).estMort()) //on execute cette ligne que si le joueurs concerne n'est pas mort
			{
				lesJoueurs.get(connection).action(Integer.parseInt(infos[1]), lesJoueurs, lesMurs);
				
			}
			
		
		}
		
		
	}

	@Override
	public void deconnection(Connection connection) {
		// TODO Auto-generated method stub
		lesJoueurs.get(connection).departJoueur(); //on fait appel a la methode departJoueurs sur le joueur concerne
		lesJoueurs.remove(connection);//on supprime le joueur en question du dictionnaire
	}
	
	public void constructionMurs() // cette methode va s'occuper de generer les murs
	{
		for (int i  = 0 ; i < NBMURS ; i ++)
		{
			lesMurs.add(new Mur());
		controle.evenementModele(this , "ajout mur" , lesMurs.get(i).getlabel().getjLabel());
		}
		
	}
	
	public void nouveauLabelJeu (Label label)
	{
		controle.evenementModele(this, "ajout joueur", label.getjLabel());
		
	}


	public void envoi(Object info) { //on surcharge la methode en la redifinissant une nouvelle fois mais en changeant les parametres
		// TODO Auto-generated method stub
		for (Connection cle : lesJoueurs.keySet() )
		{
			super.envoi(cle , info);
			
		}
	}
	
	
	

}
