package modele;

import javax.swing.JPanel;

import controleur.Controle;
import outils.connexion.Connection;

public class JeuClient extends Jeu {
	
	private Connection connection;

	public JeuClient (Controle controle)
	{
		super.controle = controle;
	}
	
	@Override
	public void setConnetion(Connection connection) {
		// TODO Auto-generated method stub
		this.connection = connection; //on valorise 
	}

	@Override
	public void reception(Connection connection, Object info) {
		// TODO Auto-generated method stub
		// le jeu c�t� client r�ceptionne l'information provenant du serveur et sollicite le controleur pour l'ajout du panel
		if (info instanceof JPanel)
		{
			controle.evenementModele(this, "ajout panels murs", info );
		}else if (info instanceof Label)
		{
			controle.evenementModele(this, "ajout joueur", info);
		}else if(info instanceof String)
		{
			controle.evenementModele(this, "remplace chat", info);
		}else if (info instanceof Integer)
		{
			controle.evenementModele(this, "son", info);
		}
		
	}

	@Override
	public void deconnection(Connection connection) {
		// TODO Auto-generated method stub
		System.exit(0);//on arrete l'application
	}
	
	public void envoi(Object info)
	{
		super.envoi(connection, info);//on envoie l'info vers l'ordi distant
	}

}
