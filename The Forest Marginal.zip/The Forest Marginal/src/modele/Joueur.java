package modele;

import java.awt.Font;
import java.util.ArrayList;
import java.util.Hashtable;

import javax.swing.ImageIcon;
import javax.swing.JLabel;
import javax.swing.SwingConstants;

import controleur.Global;
import outils.connexion.Connection;

public class Joueur extends Objet 

implements Global

{
	private String pseudo;
	private int numPerso;
	private Label message;//second label pour l'affichahe du pseudo et de la vie
	private JeuServeur jeuServeur;
	private int vie;
	private int orientation;
	private int etape;
	private Boule boule;
	private int numArme;
	
	private static final int MAXVIE  = 10; // vie de d�part pour tous les joueurs
	private static final int GAIN =1 ;  // gain de points lors d'une attaque
	private static final int PERTE = 2; // perte de points lors d'une attaque
	
	

	//Constructeur
	public Joueur (JeuServeur jeuServeur)
	{
		//on valorise 
		this.jeuServeur = jeuServeur;
		
		vie  = MAXVIE; // vie restante du joueur
     	orientation = 1;  // tourn� vers la gauche (0) ou vers la droite (1) 
		etape = 1;  // num�ro d'�tape dans l'animation
	}
	
	public void initPerso(String pseudo , int numPerso , Hashtable<Connection, Joueur> lesJoueurs , ArrayList<Mur> lesMurs, int numArme)//cette methode s'occuper egalement de generer les labels necessaires
	{
		//on valorise les 2 propriete prives
		this.pseudo = pseudo;
		this.numPerso = numPerso;
		this.numArme = numArme;
	    label = new Label(Label.getNbLabel() , new JLabel()); //on cree la propriete label en lui affectant une instance de la classe label
		Label.setNbLabel(Label.getNbLabel()+1);//on incremente le set label a notre getlabel en faisant +1 
		
		label.getjLabel().setHorizontalAlignment(SwingConstants.CENTER); //on centre horizentalement le jlabel qui se trouve dans le label que l'on vient de cree
		label.getjLabel().setVerticalAlignment(SwingConstants.CENTER);//on centre verticalement 
		
		this.jeuServeur.nouveauLabelJeu(label);
		
		 message = new Label(Label.getNbLabel() , new JLabel());//on cree la propriete message 
		Label.setNbLabel(Label.getNbLabel()+1);//on recup le dernier label cree
		message.getjLabel().setHorizontalAlignment(SwingConstants.CENTER); //on centre horizentalement
		
		message.getjLabel().setFont(new Font("Dialog" , Font.PLAIN , 8));//on modifie la police
		
		premierePosition(lesJoueurs , lesMurs );
		
		this.jeuServeur.nouveauLabelJeu(message);
		
		affiche(MARCHE , etape);
		
		 boule = new Boule(jeuServeur);
		 jeuServeur.envoi(boule.getlabel());//on envoie la boule a tous les joueurs pour l'integre au jpanel du jeu
		
	}
	/////////////////////////On gere la collision du joueur et des murs/////////////////////////////////
	private boolean toucheJoueur(Hashtable<Connection, Joueur> lesJoueurs)
	{
		for (Joueur joueur : lesJoueurs.values())
		{
			if(!joueur.equals(this))
			{
				if(toucheObjet(joueur))
				{
					return true;
				}
			}
		}
		return false;
		
	}
	
	private boolean toucheMur(ArrayList<Mur> lesMurs)
	{
		for(Mur mur : lesMurs)
		{
			if (toucheObjet(mur))
			{
				return true;
			}
		}
		return false;
	}
	///////////////////////////////////////////////////////////////////////////////////////////////////////////
	private void premierePosition(Hashtable<Connection, Joueur> lesJoueurs , ArrayList<Mur> lesMurs)//On gere le positionnement du personnage
	{
		label.getjLabel().setBounds(0,0, L_PERSO, H_PERSO);
		
		do {
			
			
			posX = (int) Math.round(Math.random() * (L_ARENE -  L_PERSO )); // partie horizontale
			posY = (int) Math.round(Math.random() * (H_ARENE - H_PERSO - H_MESSAGE  )); //partie verticale
			
			
		}while(toucheJoueur(lesJoueurs) || toucheMur(lesMurs));
		
	}
	
	private int deplace(int action, int position, int orientation, int lepas, int max,
			Hashtable<Connection, Joueur> lesJoueurs, ArrayList<Mur> lesMurs) {
		//action =  // pour conna�tre l'action sollicit�e (gauche, droite�)
		//position = // pour la position de d�part
		//orientation = // pour l'orientation de d�part
		//lepas = // pour la valeur du d�placement (en positif ou n�gatif)
		//max (entier)  pour la valeur � ne pas d�passer
		//lesjoueurs // le dictionnaire de joueurs
		//lesmurs // la collection de murs
		this.orientation = orientation; //on valorise orientation , celui ci changera lorsque les fleches G ou D seront utilise
		int ancpos = position; //si le perso traverse un mur cette variable lui permettra de reprendre son ancien positionnement
		position += lepas; //on incremente la position avec lepas
		//lepas permet de faire avancer ou reculer le perso
		//On controle si on ne sort pas de l'arene
		if (position < 0) {
			position = 0;
		}
		if (position > max) {
			position = max;
		}
		if (action == GAUCHE || action == DROITE) {
			posX = position;
		} else {
			posY = position;
		}
		if (toucheMur(lesMurs) || toucheJoueur(lesJoueurs)) {
			position = ancpos; //si un mur ou un joueur est touche alors on reaffecte a position l'ancienne position
		}
		etape = etape % NBETATSMARCHE + 1; //a chaque etape la valeur d'etape on fait un modulo puis on y ajoute 1 par ex : 1 % 4 = 1 + 1 = 2 puis 2 devient la valeur d'etape et on fait 2%4 = 2 + 1 = 3 ainsi de suite
		return position;

	}
	
	public void action(int action, Hashtable<Connection, Joueur> lesJoueurs, ArrayList<Mur> lesMurs) {
		//action = contient le numero de l'action
		switch (action) {

		case GAUCHE:
			//on utilise -lepas pour le deplacement a gauche ou vers le haut
			//pour le max on donne la taille de l'arene
			posX = deplace(action, super.posX, GAUCHE, -LEPAS, L_ARENE - (H_PERSO + H_MESSAGE), lesJoueurs, lesMurs);
			break;
		case DROITE:
			posX = deplace(action, super.posX, DROITE, LEPAS, L_ARENE - (H_PERSO + H_MESSAGE), lesJoueurs, lesMurs);
			break;
		case HAUT:
			posY = deplace(action, super.posY, orientation, -LEPAS, H_ARENE - (H_PERSO + H_MESSAGE), lesJoueurs,
					lesMurs);
			break;
		case BAS:
			posY = deplace(action, super.posY, orientation, LEPAS, H_ARENE - (H_PERSO + H_MESSAGE), lesJoueurs,
					lesMurs);
			break;
		case TIRE:
			//cette condition fait en sorte que tant que la trajectoire de la boule n'est pas fini on n'en renvoie pas une autre
			if (!boule.getlabel().getjLabel().isVisible()) { //si le jlabel n'est pas visible alors
				jeuServeur.envoi(FIGHT);
				boule.tireBoule(this ,lesMurs , lesJoueurs);//on appelle tireboule
			}
			break;
		}
		affiche(MARCHE, etape); //on appelle la methode affiche dans le but qu'apres l'action le personnage soit reaffiches
		//cette methode permet aussi de gerer l'envoie de l'information a tous les clients pour qu'ils soient tous informes du deplacement du joueurs
	}
	
	public void affiche (String etat , int etape)
	{
		label.getjLabel().setBounds(posX,posY, L_PERSO , H_PERSO);
		label.getjLabel().setIcon(new ImageIcon(PERSO + numPerso + etat + etape + "d" + orientation +   EXTIMAGE));
		this.jeuServeur.envoi(label);
		
		
		//on gere maintenant le jlabel message
		message.getjLabel().setBounds(posX-10,posY+H_PERSO,L_PERSO+10,H_MESSAGE );
		message.getjLabel().setText(pseudo + ":" + vie);
		this.jeuServeur.envoi(message);
	}
	
	public void gainvie ()
	{
		vie +=GAIN;
		if (vie > 10)
		{
			vie =10;
		}
		
	}
	
	public void pertevie ()
	{
		
		vie -=PERTE;
		
		if (vie < 0)
		{
			vie = 0;
		}
		
	}
	
	public boolean estMort()
	{
		if (vie == 0)
		{
			return true;
		}
		return false;
	}
	
	public void departJoueur ()
	{
		
		//on entoure tout d'un test pour controler que le label du personnage existe donc different de null
		if (this.label != null) {
			message.getjLabel().setVisible(false); //on rend invisible le perso
			label.getjLabel().setVisible(false);//on rend invisible le message
			boule.getlabel().getjLabel().setVisible(false); //on rend invisible la boule
			//on previens les autres joueurs en faisant un envoie au serveur
			jeuServeur.envoi(label);
			jeuServeur.envoi(message);
			jeuServeur.envoi(boule.getlabel());
		}
	}
	
	
	/**
	 * @return the message
	 */
	public Label getMessage() {
		return message;
	}
	
	public String getPseudo() {//on rajoute un getter sur le pseudo pour constituer correctement la phrase
		return pseudo;
	}

	public Boule getBoule() { //on cree le getter correspondant a la boule
		return boule;
	}

	/**
	 * @return the orientation
	 */
	public int getOrientation() {
		return orientation;
	}

	public int getNumArme() {
		return numArme;
	}
	
}
