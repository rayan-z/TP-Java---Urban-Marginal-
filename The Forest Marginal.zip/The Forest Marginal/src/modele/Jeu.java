package modele;

import controleur.Controle;
import outils.connexion.Connection;

public abstract class Jeu {

	//on declare la propriete controle de type controle pour que les 2 classes filles puisse y acceder;
	protected Controle controle ;
	
	public abstract void setConnetion(Connection connection); //on met un void car la methode ci-contre ne contient pas de corps 
	public abstract void reception(Connection connection , Object info); //avec la connexion nous connaissons qui a envoye le message et ensuite avec l'info on recupere le message envoye par l'ordi distant
	public void envoi(Connection connection , Object info)
	{
		connection.envoi(info);//cet objet sera envoye a l'ordinateur distant
	}
	
	public abstract void deconnection (Connection connection);

}
