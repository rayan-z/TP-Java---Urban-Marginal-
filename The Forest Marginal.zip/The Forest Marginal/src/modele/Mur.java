package modele;

import javax.swing.ImageIcon;
import javax.swing.JLabel;
import javax.swing.SwingConstants;

import controleur.Global;

public class Mur extends Objet 

implements Global
{
	//constructor
	public Mur ()
	{
	posX = (int) Math.round(Math.random() * ( L_ARENE- L_MUR)); // on calcule la largeur
	posY = (int) Math.round(Math.random() * ( H_ARENE - H_MUR)); //on calcule la hauteur
	
	
label = new Label(-1 , new JLabel()); //on cree l'objet label

label.getjLabel().setHorizontalAlignment(SwingConstants.CENTER); //On centre le contenu de maniere horizontale
label.getjLabel().setVerticalAlignment(SwingConstants.CENTER);//On centre le contenu de maniere verticale
label.getjLabel().setBounds(posX , posY , L_MUR , H_MUR);
label.getjLabel().setIcon(new ImageIcon(MUR)); //affichage du murs


	
	}
	
	
}
