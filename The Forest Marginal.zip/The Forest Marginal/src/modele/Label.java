package modele;

import java.io.Serializable;

import javax.swing.JLabel;

public class Label
implements Serializable
{
	public static int nbLabel;//ca nous permettra de memoriser le numero du dernier label 
	private int numLabel ;
	private JLabel jLabel;
	

	//on cree les getter et setter sur la propriete statique 
	public static int getNbLabel() {
		return nbLabel;
	}

	public static void setNbLabel(int nbLabel) {
		Label.nbLabel = nbLabel;
	}
	
	//Constructor
	public Label (int numLabel , JLabel jLabel)
	{
		this.numLabel = numLabel; //on valorise la propriete prive 
		this.jLabel = jLabel; //on valorise la deuxieme propriete prive 
		
		
	}

	
	//on cree les getter sur les proprietes afin de pouvoir recuperer leur contenu
	public int getNumLabel() {
		return numLabel;
	}

	public JLabel getjLabel() {
		return jLabel;
	}

	
	
}
