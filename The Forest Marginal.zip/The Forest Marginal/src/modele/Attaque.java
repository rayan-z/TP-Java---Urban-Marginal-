package modele;

import java.util.ArrayList;
import java.util.Hashtable;

import javax.swing.ImageIcon;

import controleur.Global;
import outils.connexion.Connection;

public class Attaque extends Thread  
implements Global 
{
		
	private Joueur attaquant;
    private JeuServeur jeuServeur;
    Hashtable<Connection, Joueur> lesJoueurs;
	private ArrayList<Mur> lesMurs;
    
    
    
    //Constructeur 
    public Attaque (Joueur attaquant , JeuServeur jeuServeur , ArrayList<Mur> lesMurs , Hashtable<Connection, Joueur> lesJoueurs)
    {
    	//on valorise les  propriete prive
    	this.attaquant = attaquant;
    	this.jeuServeur = jeuServeur;
    	this.lesMurs = lesMurs;
    	this.lesJoueurs = lesJoueurs;
    	
    	super.start();//cette methode va permettre de lancer le processus 
    }
    
    public void pause (long milli , int nano)
    {
    	try {
			Thread.sleep(milli, nano);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    }
    
    public void run ()
    {
    	Boule laBoule = attaquant.getBoule(); //on affecte la boule de l'attaque a la variable locale la boule
    	int orientation = attaquant.getOrientation();//on recup l'orientation de l'attaquant au debut du tir , dans le but que la boule ne change pas d'orientation meme si le joueur se deplace
    	laBoule.getlabel().getjLabel().setVisible(true);
    	Joueur victime = null;
    	attaquant.affiche(MARCHE, 1);
    	
    	
    	
    	do {
    		//on commence a faire avancer la boule , ici si l'orientation est de gauche alors on soustrait lEPAS pour que la boule parte a gauche sinon on ajoute pour qu'elle parte a droite
			if (orientation == GAUCHE) {
				laBoule.setPosX(laBoule.getPosX() - LEPAS);
			} else {
				laBoule.setPosX(laBoule.getPosX() + LEPAS);
			}
			laBoule.getlabel().getjLabel().setBounds(laBoule.getPosX(), laBoule.getPosY(), L_BOULE, H_BOULE);//on positionne la boule au position posx et posy
			this.pause(10, 0);//on donne une vitesse normale a la boule 
			
			
			jeuServeur.envoi(laBoule.getlabel());//on envoie la position a tous les autres joueurss
			
		victime = toucheJoueur(); //si aucun joueur est touche victime restera a null sinon il contiendra le joueur touche	
		} while (laBoule.getPosX() > 0 && laBoule.getPosX() < L_ARENE && toucheMur() == false && victime == null );//tant que posx est compris entre 0 et L_arene , qu'on ne touche pas un mur et que victime est a null
    
    	if(victime != null && !victime.estMort())
    	{
    	jeuServeur.envoi(HURT);
    	victime =toucheJoueur();
    	victime.pertevie();  
    	attaquant.gainvie();
    	
    	for (int i = 1; i <= NBETATSBLESSE; i++) {
			victime.affiche(BLESSE, i); //on affiche les images du persos blesse
			this.pause(80, 0);

		}
    	
    	if (victime.estMort()) //on gere la mort du perso
    	{
    		jeuServeur.envoi(DEATH);
    		for (int i = 1; i <= NBETATSMORT; i++) {
    			victime.affiche(MORT, i);
    			
    		}
    		
    	} else {
    		
    		victime.affiche(MARCHE, 1);//on remet le personnage a son image de base
    	}
    	
    	
    	attaquant.affiche(MARCHE, 1);//pour rendre visible les modifs de la vie 
    	
    	}
    		
    	
    	
    	laBoule.getlabel().getjLabel().setVisible(false);
    jeuServeur.envoi(laBoule.getlabel());
    
    
    }
    
    

	public boolean toucheMur()//on gere la collision de la boule avec les murs
    {
    	for (Mur unMur : lesMurs) {
			if (attaquant.getBoule().toucheObjet(unMur)) {
				return true;
			}
		}
		return false;
    }
    
    public Joueur toucheJoueur() { //on gere la collision entre la boule et le joueur
		for (Joueur unJoueur : lesJoueurs.values()) {
			if (attaquant.getBoule().toucheObjet(unJoueur)) {
				return unJoueur;
			}
		}
		return null;
	}
    
   
    
}
