package modele;

import java.util.ArrayList;
import java.util.Hashtable;

import javax.swing.ImageIcon;
import javax.swing.JLabel;
import javax.swing.SwingConstants;

import controleur.Global;
import outils.connexion.Connection;

public class Boule extends Objet 
implements Global
{
	
	
	private JeuServeur jeuServeur; //on declare cette propriete  dans le but de pouvoir envoyer le jlabel de la boule dans le jpanel cote serveur et l'envoyer a tout le monde
	
	
	//Constructeur
	public Boule (JeuServeur jeuServeur) {
		//on valorise la propriete privee
		this.jeuServeur = jeuServeur;
		//on cree le label de la boule // on utilise la propriete nbLabel qui est un compteur qui nous permet de numeroter les JLabels du Jpanel du Jeu
		super.label = new Label(Label.nbLabel++, new JLabel());
		//ajoutons lui desormais des caracteristiques
		super.label.getjLabel().setHorizontalAlignment(SwingConstants.CENTER); //on centre le jlabel de maniere horizentale 
		super.label.getjLabel().setVerticalAlignment(SwingConstants.CENTER);//puis de maniere verticale
		//on fixe la taille du jlabel de la boule 
		super.label.getjLabel().setBounds(0,0, L_BOULE , H_BOULE); // on la laisse pour le moment en 0 0
		//on affecte l'image de la boule au Jlabel
		
		//on rend le jlabel invisible
		super.label.getjLabel().setVisible(false);
		
		jeuServeur.nouveauLabelJeu(super.label);//le Jlabel est ajoute au Jpanel cote serveur
		
		
		
	}
	public void tireBoule(Joueur attaquant , ArrayList<Mur> lesMurs  ,Hashtable<Connection, Joueur> lesJoueurs)//cette methode initialise la position de depart de la boule et lance le tir 
	{
		super.label.getjLabel().setIcon(new ImageIcon(BOULE2 + attaquant.getNumArme() + ".gif"));
		if(attaquant.getOrientation() == GAUCHE)
		{
			this.posX = attaquant.getposX()-L_BOULE-1; //si l'attaquant est tourne vers la gauche alors on affecte dans posx le posx de l'attauqant dans le but que la boule ne touche pas le joueur
		}else if (attaquant.getOrientation() == DROITE)
		{
			this.posX = attaquant.getposX()+L_PERSO + 1;
		}
		
		this.posY = attaquant.posY + (H_PERSO/2); //on ajoute a posy le posy de l'attaquant plus la moitie de la hauteur du perso pour que la boule soit positionne vers le milieu du personnage
		new Attaque (attaquant , jeuServeur , lesMurs , lesJoueurs);//on instancie la classe attaque 
	}
	
	
}
